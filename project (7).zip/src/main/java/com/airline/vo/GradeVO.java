package com.airline.vo;

public class GradeVO {

}
